import { queryClient } from '@/shared/lib/queryClient';
import { useSessionStore } from '@/shared/stores/sessionStore';
import type { SignOutReason } from '@/shared/stores/sessionStore';
import { useToastStore } from '@/shared/stores/toastStore';
import { useUiStore } from '@/shared/stores/uiStore';
import { useProjectDialogStore } from '@/features/projects/store/projectDialogStore';

/**
 * Clears the token, the user, every cached query and the client stores (UI state, toasts,
 * open project dialogs). The route guards then show /login.
 */
export function signOut(reason: SignOutReason | null): void {
  useSessionStore.getState().endSession(reason);
  queryClient.clear();
  useUiStore.getState().reset();
  useToastStore.getState().reset();
  useProjectDialogStore.getState().reset();
}

/**
 * Called by the API client for every 401 except a failed login (AUTH-6).
 * Idempotent: several requests failing at once end the session only once.
 * A 401 while the stored token is being verified at startup is silent (no "expired" message).
 */
export function expireSession(): void {
  const { status } = useSessionStore.getState();
  if (status === 'unauthenticated') return;
  signOut(status === 'authenticated' ? 'session-expired' : null);
}
